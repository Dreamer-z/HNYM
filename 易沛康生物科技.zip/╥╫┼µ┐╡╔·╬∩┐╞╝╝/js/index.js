var mySwiper = new Swiper('.swiper-container', {
    autoplay: 3000, //可选选项，自动滑动
    loop: true,
    speed: 1000,
    autoplayDisableOnInteraction: false,
    pagination: '.swiper-pagination',
})